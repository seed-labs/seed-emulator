SCION artifacts not found in this output. When compiling a SCION topology, SEED will copy topology.json and keys here (best-effort discovery).
