#!/bin/bash
set -euo pipefail

# External component: ext-r0 (role=router, asn=65000, impl=generic)
# Usage:
#   sudo IFACE=<your-physical-or-tap-interface> ./attach_linux.sh

IFACE="${IFACE:-}"
if [ -z "$IFACE" ]; then
  echo "ERROR: Set IFACE, e.g.: sudo IFACE=eth1 ./attach_linux.sh" >&2
  exit 1
fi

echo "Bringing up $IFACE for external component..."
ip link set "$IFACE" up

# Interface eth0 -> SEED network 'ix100'
ip link set dev "$IFACE" address 02:00:00:00:00:01
ip addr flush dev "$IFACE" || true
ip addr add 10.0.0.2/24 dev "$IFACE"

ip addr show dev "$IFACE"
echo "OK. Now connect this interface into your hardware/standalone emulation fabric (bridge/tap)."

